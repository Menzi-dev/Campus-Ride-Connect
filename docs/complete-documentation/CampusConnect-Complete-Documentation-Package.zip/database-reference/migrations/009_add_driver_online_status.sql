USE campus_connect;

ALTER TABLE drivers
    ADD COLUMN online BOOLEAN NOT NULL DEFAULT FALSE;
